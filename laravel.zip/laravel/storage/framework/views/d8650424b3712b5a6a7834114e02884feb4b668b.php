<html>


<h1> scoylist Form </h1>

<form method="post" action="<?php echo e(URL::to('/submit')); ?>">

<input name="ahmed" type="text">


<button type="submit"> submit</button>
</form> 
</html><?php /**PATH C:\xampp\htdocs\laravel\laravel\resources\views/socylist.blade.php ENDPATH**/ ?>