<html>


<h1> socylist Form </h1>

<form method="post" action="{{URL::to('/submit')}}">

<input name="ahmed" type="text">


<button type="submit"> submit</button>
</form> 
</html>